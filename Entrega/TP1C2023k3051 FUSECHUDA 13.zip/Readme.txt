Curso: K3051

Numero de grupo: 13

Integrantes
Nombre: Ivan D'Amario Tomasello
Legajo: 1645419

Nombre: Federico Fukushima
Legajo: 1284939

Nombre: Guido Segesso
Legajo: 1687580

Nombre: Belen Chura Flores
Legajo: 1558432

Mail: idamariotomasello@frba.utn.edu.ar